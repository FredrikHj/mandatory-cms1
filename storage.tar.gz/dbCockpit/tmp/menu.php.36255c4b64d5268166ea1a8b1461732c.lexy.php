<ul class="uk-nav uk-nav-side uk-nav-dropdown uk-margin-top">

    <li class="uk-nav-header"><?php echo $app("i18n")->get('Collections'); ?></li>

    <?php foreach ($collections as $collection) { ?>
    <li>
        <a class="uk-flex uk-flex-middle" href="<?php $app->route('/collections/entries/'.$collection['name']); ?>">
            <i class="uk-icon-justify"><img class="uk-svg-adjust" src="<?php $app->base('collections:icon.svg'); ?>" width="20" height="20" data-uk-svg></i> <?php echo  htmlspecialchars($collection['label'] ? $collection['label'] : $collection['name']) ; ?>
        </a>
    </li>
    <?php } ?>
</ul>
